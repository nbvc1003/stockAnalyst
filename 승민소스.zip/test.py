import numpy as np
import tensorflow as tf
from get_data import stock_2_data
tf.compat.v1.disable_eager_execution()
# min-max 정규화 [ 5 6 7 ] -> [0~1]
# (x - min(x))/ (max(x)-min(x))
# (x - 5) / (7 - 5 )
# (5 - 5) / (7 - 5 ) = 0 = 0.0
# (6 - 5) / (7 - 5 ) = 1/2 = 0.5
# (7 - 5) / (7 - 5 ) = 2/2 = 1.0
tf.compat.v1.disable_eager_execution()
data = np.loadtxt('B:/Workspace/08.AI/data/data-02-stock_daily.csv',
                  dtype = np.float32, delimiter = ',')
print (data)
print (data.shape)
x_train = data[:, 0:4]
y_train = data[:, 4:5]
print (x_train.shape)
print (y_train.shape)
def normalize(input):
    max = np.max(input, axis = 0)
    min = np.min(input, axis = 0)
    out = (input - min)/(max-min)
    print (min)
    print (max)
    return out

x_data = normalize(x_train)
y_data = normalize(y_train)
testM=10
m = len(x_train)-testM
print ('m', m)
x_train = x_data[0:m,:]
y_train = y_data[0:m,:]
x_test = x_data[m:,:]
y_test = y_data[m:,:]
X = tf.compat.v1.placeholder(tf.float32,shape=[None, 4])
Y = tf.compat.v1.placeholder(tf.float32,shape=[None, 1])
w = tf.Variable(tf.ones([4, 1],tf.float32))
b = tf.Variable(0.0)
hypothesis = tf.matmul(X,w) + b
loss = tf.square(Y - hypothesis)#오류
loss = tf.reduce_mean(loss)#모든 샘플의 오류 평균
optimizer=tf.compat.v1.train.GradientDescentOptimizer(learning_rate=1e-1)#학습기
train = optimizer.minimize(loss)#학습
sess=tf.compat.v1.Session()
sess.run(tf.compat.v1.global_variables_initializer())#변수 초기화
epoch =10000
for iter in range(epoch):
    t_,w_,l,h = sess.run([train,w,loss,hypothesis],
        feed_dict={X:x_train,Y:y_train } )
    if iter%(epoch/10)==0: print('iter:%d, loss:%f ' %(iter,l))#학습
h=sess.run(hypothesis, feed_dict={X:x_test})
print('Input',x_test)
print('Close Price Predict',h)
print('Close Price Real',y_test)
print('why',sess.run(w))
sess.close()