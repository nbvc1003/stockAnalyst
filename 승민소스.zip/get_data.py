from urllib.request import urlopen

import pandas as pd
from bs4 import BeautifulSoup as bs


def del_comma(st):              # 문자의 컴마 없애는 함수
    ar = st.split(',')
    k = ''
    for i in ar:
       k += i
    return k 

def str2fl(st):
    return float(st)


def stock_1_data(data_len, stock_num):             # 데이터 1개 파싱
    stock_num =  stock_num # input('종목 코드 입력 : ')
    data_len1 =  data_len # input('가져올 데이터 수 (10 단위로 입력 가능): ')
    data_len2 = int(int(data_len1) / 10)

    if str(data_len1)[-1] == '0':
        date_list = []
        stock_list = []

        for n in range(1, data_len2+1):
            url = f'http://finance.naver.com/item/sise_day.nhn?code={stock_num}&page={n}'
            html = urlopen(url)
            source = bs(html.read(), 'html.parser')
            sr_lists = source.find_all('tr')
            for j in sr_lists:
                if j.span != None:
                    date_list.append(j.td.text)
                    stock_list.append(j.find_all('td', class_ = 'num')[0].text)

            df = pd.Series(stock_list, 
                        index = date_list)
            df = df.map(del_comma)
            df = df.map(str2fl)

        result = pd.DataFrame(df,
                              columns = [stock_num]).sort_index()
        
    else:
        result = f'데이터는 10배수로만 가져올 수 있습니다. 입력한 수 : {data_len1}'    
    
    return result

def stock_2_data(data_len, stock_num1, stock_num2):             # 데이터 두개 파싱
    stock_num1 = stock_num1 # input('첫 번째 종목 코드 입력 : ')
    stock_num2 = stock_num2 # input('두 번째 종목 코드 입력 : ')
    data_len1 = data_len # input('가져올 데이터 수 (10 단위로 입력 가능): ')
    data_len2 = int(int(data_len1) / 10)

    if str(data_len1)[-1] == '0':
        search_list = [stock_num1, stock_num2]
        date_list = []
        stock_list = []

        for stock_num in search_list: 
            for n in range(1, data_len2+1):
                url = f'http://finance.naver.com/item/sise_day.nhn?code={stock_num}&page={n}'
                html = urlopen(url)
                source = bs(html.read(), 'html.parser')
                sr_lists = source.find_all('tr')
                for j in sr_lists:
                    if j.span != None:
                        date_list.append(j.td.text)
                        stock_list.append(j.find_all('td', class_ = 'num')[0].text)

            df = pd.Series(stock_list, 
                        index = date_list)
            df = df.map(del_comma)
            df = df.map(str2fl)
            
        stock_1 = df[:int(len(df)/2)]
        stock_2 = df[int(len(df)/2):]
        result = pd.concat([stock_1, stock_2], 
                           axis = 1, 
                           keys = [stock_num1, stock_num2]).sort_index()
    else:
        result = f'데이터는 10배수로만 가져올 수 있습니다. 입력한 수 : {data_len1}'    
    
    return result

def get_stocklist():
    df = pd.read_html('http://kind.krx.co.kr/corpgeneral/corpList.do?method=download&searchType=13', header=0)[0]
    df[df.columns[1]] = df[df.columns[1]].map('{:06d}'.format)
   
    return df
    
# exception
# # Value Error
# ## 가져올 데이터 수에 알파벳 입력했을 때
# ## 종목코드가 존재 하지 않을 때
# ## 종목코드에 숫자가 아닌 데이터를 입력했을 때

# # Unicode Error
# ## 종목코드에 한글을 입력했을 때