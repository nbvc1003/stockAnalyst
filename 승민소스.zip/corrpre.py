from scipy import stats

def data_corr(data):
    slope, intercept, r_value, p_value, stderr = stats.linregress(data[data.columns[0]], data[data.columns[1]])
    result = [slope, intercept, r_value, p_value, stderr]
    return result

def pred():
    pass
