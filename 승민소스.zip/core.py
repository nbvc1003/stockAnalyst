import os
import sys
import time

import matplotlib.pyplot as plt
import pandas as pd
from matplotlib import font_manager, rc, rcParams
from PyQt5 import *
from PyQt5 import uic
from PyQt5.QtWidgets import *
from numpy import polyval

from corrpre import data_corr, pred
from design import Ui_MainWindow
from get_data import get_stocklist, stock_1_data, stock_2_data
from table_view import df_tableView

font_name = font_manager.FontProperties(
    fname = 'c:/Windows/Fonts/malgun.ttf'
).get_name()
rc('font', family = font_name)
rcParams['axes.unicode_minus'] = False

# Ui_MainWindow = uic.loadUiType('UI/19.12.30.ui')[0]

class WindowClass(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setWindowTitle('v.19.12.31')
        
        # UI Buttons
        # tab_1 : 종목 리스트 및 코드 검색
        self.Load_data_btn.clicked.connect(self.load_data)
        self.Search_btn1.clicked.connect(self.find_number)
        self.stock_name.returnPressed.connect(self.find_number)
        self.stock_name.setEnabled(False)
        self.Search_btn1.setEnabled(False)

        # tab_2 : 두 종목 상관관계 분석
        self.Start_btn2.clicked.connect(self.start_corr_stats)
        self.show_graph_btn.clicked.connect(self.show_graph)
        self.Reset_btn2.clicked.connect(self.stop_corr)
        self.data_len.returnPressed.connect(self.start_corr_stats)
        self.stock_num1.returnPressed.connect(self.start_corr_stats)
        self.stock_num2.returnPressed.connect(self.start_corr_stats)
        self.Reset_btn2.setEnabled(False)
        self.stock.setEnabled(False)
        self.cor.setEnabled(False)
        self.pred_1.setEnabled(False)
        self.pred_2.setEnabled(False)
        self.show_graph_btn.setEnabled(False)
        
        # tab_3 : 데이터 검색 및 추출
        ## 버튼 및 입력 창
        self.Search_btn3.clicked.connect(self.copy_data_s)
        self.Reset_btn3.clicked.connect(self.stop_search)
        self.data_len_2.returnPressed.connect(self.copy_data_s)
        self.stock_num.returnPressed.connect(self.copy_data_s)
        self.save_btn3.clicked.connect(self.save2csv)
        self.Reset_btn3.setEnabled(False)
        self.save_btn3.setEnabled(False)
       
    # UI Actions
    # tab1
    def load_data(self):
        self.stock_name.setEnabled(True)
        self.Search_btn1.setEnabled(True)
        
        global stock_list
        stock_list = get_stocklist()
        self.result_1.setText(f'{len(stock_list)}개의 데이터를 불러왔습니다.')
    
        model = df_tableView(stock_list)
        self.tableView_Stocklist.setModel(model)
        
    def find_number(self):
        df = stock_list
        df.set_index(df[df.columns[0]], inplace = True)
        stock_name = self.stock_name.text()

        if len(stock_name) == 0:
            result = '입력된 검색어가 없습니다.'
            model = df_tableView(df.head(0))
            stock_num = ''        
            
        elif stock_name not in list(df[df.columns[0]]):
            result = '일치하는 종목이 없습니다.'
            model = df_tableView(df.head(0))
            stock_num = ''

        elif stock_name in list(df[df.columns[0]]):
            target_data = pd.DataFrame(df.loc[f'{stock_name}']).T
            model = df_tableView(target_data)
            stock_num = list(df.loc[f'{stock_name}'])[1]
            result = f'{stock_name}에 대한 검색을 완료했습니다.'
        self.tableView_Stocklist.setModel(model)        
        self.result_1.setText(result)
        self.stock_number.setText(stock_num)
    # tab2
    def start_corr_stats(self): # 상관계수 출력
        global corr_list
        global stock_prices
        global stock_name_list
        global data_len1
        
        corr_list = []
        data_len1 = self.data_len.text()
        stock_num1 = str(self.stock_num1.text())
        stock_num2 = str(self.stock_num2.text())
        
        df = get_stocklist()
        df.set_index(df[df.columns[1]], inplace = True)
        try:
            if len(str(data_len1)) == 0:
                text = '불러올 데이터 갯수를 입력하세요.'
            elif len(str(stock_num1)) == 0:
                text = '종목 코드 1을 입력하세요.'
            elif len(str(stock_num2)) == 0:
                text = '종목 코드 2를 입력하세요.'
            elif stock_num1 == stock_num2:
                text = '같은 종목 코드를 넣을 수 없습니다.'
            elif data_len1.isdigit() == False:
                text = '데이터 갯수는 숫자로만 입력가능합니다'
            elif stock_num1.isdigit() == False:
                text = '종목코드는 숫자로만 입력가능합니다.'
            elif stock_num2.isdigit() == False:
                text = '종목코드는 숫자로만 입력가능합니다.'
            elif int(data_len1) % 10 != 0:
                text = '올바른 데이터 갯수가 아닙니다. (10의 배수로만 입력가능)'
            elif (stock_num1 or stock_num2) not in list(df[df.columns[1]]):
                raise KeyError
            else:
                self.Start_btn2.setEnabled(False)
                self.Reset_btn2.setEnabled(True)
                self.data_len.setEnabled(False)
                self.stock_num1.setEnabled(False)
                self.stock_num2.setEnabled(False)
                self.stock.setEnabled(True)
                self.cor.setEnabled(True)
                self.pred_1.setEnabled(True)
                self.pred_2.setEnabled(True)
                self.show_graph_btn.setEnabled(True)
                
                stock_name1 = list(df.loc[f'{stock_num1}'])[0]
                stock_name2 = list(df.loc[f'{stock_num2}'])[0]
                stock_name_list = [stock_name1, stock_name2]
                
                df = stock_2_data(data_len1, stock_num1, stock_num2)
                stock_prices = df
                corr_list = data_corr(df)
                corr = \
f'''=========={stock_name1}~{stock_name2}==========
slope : {round(corr_list[0], 5)}
intercept : {round(corr_list[1], 5)}
r-value : {round(corr_list[2], 5)}
p-value : {round(corr_list[3], 5)}'''
                text = f'{stock_name1}와(과) {stock_name2}에 대한 분석을 완료했습니다.'
                self.stats.append(corr)
        except KeyError:
            text = '존재하지 않는 종목 코드 입니다. (첫번째 탭에서 확인가능)'
        finally:
            self.result_2_1.setText(text)
    
    def show_graph(self):        
        text = '그래프 종류를 선택하세요.'
        df = stock_prices
        if self.stock.isChecked():
            text = '주가 그래프 생성 완료'
            title = f'최근 {data_len1}일간 주가'
            xlabel = 'data'
            ylabel = 'price'
            legend = stock_name_list
            df.plot()
            plt.legend(legend)
        elif self.cor.isChecked():
            text = '상관관계 그래프 생성 완료'
            data1 = list(df[df.columns[0]])
            data2 = list(df[df.columns[1]])
            ry = polyval([corr_list[0], corr_list[1]], data1)
            title = f'{stock_name_list[0]}와 {stock_name_list[1]} 관계'
            xlabel = f'{stock_name_list[0]}'
            ylabel = f'{stock_name_list[1]}'
            plt.plot(data1, data2, 'k.')
            plt.plot(data1, ry, 'r')
        elif self.pred_1.isChecked():
            text = f'{stock_name_list[0]} 예측 그래프 생성 완료'

        elif self.pred_1.isChecked():
            text = f'{stock_name_list[1]} 예측 그래프 생성 완료'

            
        self.result_2_2.setText(text)
        plt.title(title)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.show()        
    
    def stop_corr(self):
        self.Start_btn2.setEnabled(True)
        self.Reset_btn2.setEnabled(False)
        self.data_len.setEnabled(True)
        self.stock_num1.setEnabled(True)
        self.stock_num2.setEnabled(True)
        self.stock.setEnabled(False)
        self.cor.setEnabled(False)
        self.pred_1.setEnabled(False)
        self.pred_2.setEnabled(False)
        self.show_graph_btn.setEnabled(False)
        self.result_2_1.setText('초기화되었습니다.')
    # tab3
    def copy_data_s(self):
        global result, stock_num_list, target
        
        data_len = self.data_len_2.text()
        stock_num = str(self.stock_num.text())
        
        df = get_stocklist()
        df.set_index(df[df.columns[1]], inplace = True)
        text = ''
        try:
            if len(str(data_len)) == 0:
                text = '불러올 데이터 갯수를 입력하세요.'
            elif len(str(stock_num)) == 0:
                text = '종목 코드를 입력하세요.'
            elif data_len.isdigit() == False:
                text = '데이터 갯수는 숫자로만 입력가능합니다'
            elif stock_num.isdigit() == False:
                text = '종목코드는 숫자로만 입력가능합니다.'
            elif int(data_len) % 10 != 0:
                text = '올바른 데이터 갯수가 아닙니다. (10의 배수로만 입력가능)'
            elif stock_num not in list(df[df.columns[1]]):
                raise KeyError
            else:
                self.Reset_btn3.setEnabled(True)
                self.data_len_2.setEnabled(False)
                self.save_btn3.setEnabled(True)

                if 'target' not in globals():
                    target = stock_1_data(data_len, stock_num)
                    stock_num_list = []
                    
                    stock_name = list(df.loc[f'{stock_num}'])[0]
                    target = target.reset_index().rename(
                        columns = {'index':'date', 
                                    target.columns[0]: f'{stock_name}'}
                    )
                    text = f'{data_len}개의 {stock_name} 데이터를 불러왔습니다.'
                else:
                    if stock_num not in stock_num_list:
                        add = stock_1_data(data_len, stock_num)
                        stock_name = list(df.loc[f'{stock_num}'])[0]
                        add = add.reset_index().rename(
                            columns = {'index':'date', 
                                    add.columns[0]: f'{stock_name}'}
                        )
                        target = pd.merge(target, add[add.columns[1]], 
                                        how = 'outer', 
                                        left_index = True, 
                                        right_index = True)
                        text = f'{data_len}개의 {stock_name} 데이터를 불러왔습니다.'
                    else:
                        text = f'이미 존재하는 종목입니다.'
                        stock_num_list.remove(stock_num)

                result = target
                stock_num_list.append(stock_num)
                model = df_tableView(result)
                self.tableView.setModel(model)
        except KeyError:
            text = '존재하지 않는 종목 코드 입니다. (첫번째 탭에서 확인가능)'
        finally:
            self.result_3.setText(text)

    def stop_search(self):
        global result, stock_num_list, target
        
        self.Search_btn3.setEnabled(True)
        self.Reset_btn3.setEnabled(False)
        self.data_len_2.setEnabled(True)
        self.stock_num.setEnabled(True)
        self.save_btn3.setEnabled(False)

        self.result_3.setText('초기화되었습니다.')
        
        del target
        stock_num_list = []

    def save2csv(self):
        global result
        
        folderPath = QFileDialog.getExistingDirectory()
        folderPath = os.path.realpath(folderPath)

        result.to_csv(f'{folderPath}\\data.csv', 
                      mode = 'w', 
                      index = False, 
                      encoding = 'euc-kr')
        
        self.result_3.setText(f'저장 위치 : {folderPath}')

if __name__ == '__main__':
    app = QApplication(sys.argv)
    myWindow = WindowClass()
    myWindow.show()
    app.exec_()
